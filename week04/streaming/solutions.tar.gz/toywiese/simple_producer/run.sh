#!/usr/bin/env bash

sleep 10
python simple_producer.py
