#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
from kafka import KafkaProducer
from time import time
import json

if __name__ == "__main__":
    KAFKA_SERVER = os.environ.get("KAFKA_SERVER", "localhost:9092")
    producer = KafkaProducer(bootstrap_servers=KAFKA_SERVER)

    producer.send("test-topic", b"Pepe the frog.")


def get_time_ms():
    return int(time() * 1000.0)


def send_message(producer, data):
    msg = {
        "payload": data,
        "time": get_time_ms()
    }

    producer.send("test-topic", json.dumps(msg))

producer = KafkaProducer(bootstrap_servers=KAFKA_SERVER)
                         # client_id="Producer number {}"
                         # compression_type="gzip",
                         # value_serializer=lambda val: json.dumps(val))
