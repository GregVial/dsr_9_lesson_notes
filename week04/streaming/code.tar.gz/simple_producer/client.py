from kafka import KafkaProducer
from time import sleep
from time import time
import json
KAFKA_SERVER = "localhost:9092"

producer = KafkaProducer(bootstrap_servers=KAFKA_SERVER,
                         value_serializer=lambda value: json.dumps(value),
                         client_id="Test Producer")


def create_message():
    msg = {
        'time': int(time() * 1000.0),
        'msg': "Hi!"
    }

    return msg

for i in xrange(10):
    msg = create_message()
    producer.send("test-topic", msg)  # Python 3: bytes(json.dumps(msg), "utf-8")
    sleep(5)
