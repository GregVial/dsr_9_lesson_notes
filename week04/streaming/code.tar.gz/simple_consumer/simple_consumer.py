#!/usr/bin env python
# -*- coding: utf-8 -*-
import os
from kafka import KafkaConsumer
from time import time
import logging


def get_time_ms():
    return int(time() * 1000.0)

if __name__ == "__main__":
    logging.basicConfig(
        format='%(asctime)s.%(msecs)s:%(name)s:%(thread)d:%(levelname)s:%(process)d:%(message)s',
        level=logging.INFO)

    KAFKA_SERVER = os.environ.get("KAFKA_SERVER", "localhost:9092")
    CONSUME_TOPICS = os.environ.get("CONSUME_TOPICS", "test-topic").split(",")

    consumer = KafkaConsumer(bootstrap_servers="localhost:9092",
                             client_id="Simple Consumer",
                             group_id="Simple",  # very important!
                             auto_offset_reset='earliest')

    consumer.subscribe(CONSUME_TOPICS)

    for msg in consumer:
        print msg
